﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using RohitWeb.Models;

using RohitWeb.ContextClass;

namespace RohitWeb.Controllers
{
    public class UserManagementController : Controller
    {
        //
        // GET: /UserManagement/
        public ActionResult Index()
        {
            var lstUser=LoadData();
            ViewBag.Users = lstUser.OrderByDescending(l=>l.Id).ToList();
            return View();
        }

        private List<User> LoadData()
        {
            RohitContext dbCtx = new RohitContext();
            List<User> lstUser = dbCtx.users.ToList();
            dbCtx.Dispose();
           
            return lstUser;
        }

        public ActionResult Save(User user)
        {
            RohitContext dbCtx = new RohitContext();
            dbCtx.users.Add(user);
          //  dbCtx.users.Remove(user);
            dbCtx.SaveChanges();
            dbCtx.Dispose();
            return RedirectToAction("Index", "UserManagement");
        }
	}
}