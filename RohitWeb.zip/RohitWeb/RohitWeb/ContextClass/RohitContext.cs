﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.Entity;
using RohitWeb.Models;


namespace RohitWeb.ContextClass
{
    public class RohitContext:DbContext
    {
        public RohitContext():base("name=constr")
        {

        }

        public DbSet<User> users { get; set; }

    }
}